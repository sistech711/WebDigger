#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "Please Run as Root" 
   exit 1
fi

{
    for ((i = 0 ; i <= 100 ; i+=5)); do
        sleep 0.01
        echo $i
    done
} | whiptail --gauge "WebDigger Is Loading..." 6 50 0

echo "Installing";
sudo cp webkit.zip /opt/
cd
cd /opt/
sudo unzip webkit.zip
rm webkit.zip
cd
bash /opt/webkit/install.sh

exit
fi
